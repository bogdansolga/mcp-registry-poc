--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.0 (Postgres.app)
-- Dumped by pg_dump version 18.0 (Postgres.app)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mcp_registry;
--
-- Name: mcp_registry; Type: DATABASE; Schema: -; Owner: mcp_registry_admin
--

CREATE DATABASE mcp_registry WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


ALTER DATABASE mcp_registry OWNER TO mcp_registry_admin;

\unrestrict (null)
\connect mcp_registry
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: metrics; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA metrics;


ALTER SCHEMA metrics OWNER TO postgres;

--
-- Name: registry; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA registry;


ALTER SCHEMA registry OWNER TO postgres;

--
-- Name: server_status; Type: TYPE; Schema: registry; Owner: mcp_registry_admin
--

CREATE TYPE registry.server_status AS ENUM (
    'active',
    'inactive',
    'error'
);


ALTER TYPE registry.server_status OWNER TO mcp_registry_admin;

--
-- Name: server_type; Type: TYPE; Schema: registry; Owner: mcp_registry_admin
--

CREATE TYPE registry.server_type AS ENUM (
    'official',
    'community',
    'mock'
);


ALTER TYPE registry.server_type OWNER TO mcp_registry_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: server_health_metrics; Type: TABLE; Schema: metrics; Owner: mcp_registry_admin
--

CREATE TABLE metrics.server_health_metrics (
    id integer NOT NULL,
    server_id integer NOT NULL,
    response_time_ms integer,
    status_code integer,
    error_message text,
    checked_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE metrics.server_health_metrics OWNER TO mcp_registry_admin;

--
-- Name: server_health_metrics_id_seq; Type: SEQUENCE; Schema: metrics; Owner: mcp_registry_admin
--

CREATE SEQUENCE metrics.server_health_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metrics.server_health_metrics_id_seq OWNER TO mcp_registry_admin;

--
-- Name: server_health_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: metrics; Owner: mcp_registry_admin
--

ALTER SEQUENCE metrics.server_health_metrics_id_seq OWNED BY metrics.server_health_metrics.id;


--
-- Name: tool_invocations; Type: TABLE; Schema: metrics; Owner: mcp_registry_admin
--

CREATE TABLE metrics.tool_invocations (
    id integer NOT NULL,
    server_id integer NOT NULL,
    tool_id integer NOT NULL,
    invoked_at timestamp without time zone DEFAULT now() NOT NULL,
    duration_ms integer,
    success boolean NOT NULL
);


ALTER TABLE metrics.tool_invocations OWNER TO mcp_registry_admin;

--
-- Name: tool_invocations_id_seq; Type: SEQUENCE; Schema: metrics; Owner: mcp_registry_admin
--

CREATE SEQUENCE metrics.tool_invocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metrics.tool_invocations_id_seq OWNER TO mcp_registry_admin;

--
-- Name: tool_invocations_id_seq; Type: SEQUENCE OWNED BY; Schema: metrics; Owner: mcp_registry_admin
--

ALTER SEQUENCE metrics.tool_invocations_id_seq OWNED BY metrics.tool_invocations.id;


--
-- Name: mcp_servers; Type: TABLE; Schema: registry; Owner: mcp_registry_admin
--

CREATE TABLE registry.mcp_servers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    description text,
    server_type registry.server_type NOT NULL,
    endpoint_url character varying(512) NOT NULL,
    status registry.server_status DEFAULT 'active'::registry.server_status NOT NULL,
    version character varying(50),
    last_health_check timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE registry.mcp_servers OWNER TO mcp_registry_admin;

--
-- Name: mcp_servers_id_seq; Type: SEQUENCE; Schema: registry; Owner: mcp_registry_admin
--

CREATE SEQUENCE registry.mcp_servers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE registry.mcp_servers_id_seq OWNER TO mcp_registry_admin;

--
-- Name: mcp_servers_id_seq; Type: SEQUENCE OWNED BY; Schema: registry; Owner: mcp_registry_admin
--

ALTER SEQUENCE registry.mcp_servers_id_seq OWNED BY registry.mcp_servers.id;


--
-- Name: server_metadata; Type: TABLE; Schema: registry; Owner: mcp_registry_admin
--

CREATE TABLE registry.server_metadata (
    server_id integer NOT NULL,
    author character varying(255),
    repository_url character varying(512),
    documentation_url character varying(512),
    tags jsonb
);


ALTER TABLE registry.server_metadata OWNER TO mcp_registry_admin;

--
-- Name: tools; Type: TABLE; Schema: registry; Owner: mcp_registry_admin
--

CREATE TABLE registry.tools (
    id integer NOT NULL,
    server_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    input_schema jsonb,
    category character varying(100),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE registry.tools OWNER TO mcp_registry_admin;

--
-- Name: tools_id_seq; Type: SEQUENCE; Schema: registry; Owner: mcp_registry_admin
--

CREATE SEQUENCE registry.tools_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE registry.tools_id_seq OWNER TO mcp_registry_admin;

--
-- Name: tools_id_seq; Type: SEQUENCE OWNED BY; Schema: registry; Owner: mcp_registry_admin
--

ALTER SEQUENCE registry.tools_id_seq OWNED BY registry.tools.id;


--
-- Name: server_health_metrics id; Type: DEFAULT; Schema: metrics; Owner: mcp_registry_admin
--

ALTER TABLE ONLY metrics.server_health_metrics ALTER COLUMN id SET DEFAULT nextval('metrics.server_health_metrics_id_seq'::regclass);


--
-- Name: tool_invocations id; Type: DEFAULT; Schema: metrics; Owner: mcp_registry_admin
--

ALTER TABLE ONLY metrics.tool_invocations ALTER COLUMN id SET DEFAULT nextval('metrics.tool_invocations_id_seq'::regclass);


--
-- Name: mcp_servers id; Type: DEFAULT; Schema: registry; Owner: mcp_registry_admin
--

ALTER TABLE ONLY registry.mcp_servers ALTER COLUMN id SET DEFAULT nextval('registry.mcp_servers_id_seq'::regclass);


--
-- Name: tools id; Type: DEFAULT; Schema: registry; Owner: mcp_registry_admin
--

ALTER TABLE ONLY registry.tools ALTER COLUMN id SET DEFAULT nextval('registry.tools_id_seq'::regclass);


--
-- Data for Name: server_health_metrics; Type: TABLE DATA; Schema: metrics; Owner: mcp_registry_admin
--

\i $$PATH$$/3879.dat

--
-- Data for Name: tool_invocations; Type: TABLE DATA; Schema: metrics; Owner: mcp_registry_admin
--

\i $$PATH$$/3882.dat

--
-- Data for Name: mcp_servers; Type: TABLE DATA; Schema: registry; Owner: mcp_registry_admin
--

\i $$PATH$$/3877.dat

--
-- Data for Name: server_metadata; Type: TABLE DATA; Schema: registry; Owner: mcp_registry_admin
--

\i $$PATH$$/3880.dat

--
-- Data for Name: tools; Type: TABLE DATA; Schema: registry; Owner: mcp_registry_admin
--

\i $$PATH$$/3884.dat

--
-- Name: server_health_metrics_id_seq; Type: SEQUENCE SET; Schema: metrics; Owner: mcp_registry_admin
--

SELECT pg_catalog.setval('metrics.server_health_metrics_id_seq', 1, true);


--
-- Name: tool_invocations_id_seq; Type: SEQUENCE SET; Schema: metrics; Owner: mcp_registry_admin
--

SELECT pg_catalog.setval('metrics.tool_invocations_id_seq', 1, false);


--
-- Name: mcp_servers_id_seq; Type: SEQUENCE SET; Schema: registry; Owner: mcp_registry_admin
--

SELECT pg_catalog.setval('registry.mcp_servers_id_seq', 1, true);


--
-- Name: tools_id_seq; Type: SEQUENCE SET; Schema: registry; Owner: mcp_registry_admin
--

SELECT pg_catalog.setval('registry.tools_id_seq', 2, true);


--
-- Name: server_health_metrics server_health_metrics_pkey; Type: CONSTRAINT; Schema: metrics; Owner: mcp_registry_admin
--

ALTER TABLE ONLY metrics.server_health_metrics
    ADD CONSTRAINT server_health_metrics_pkey PRIMARY KEY (id);


--
-- Name: tool_invocations tool_invocations_pkey; Type: CONSTRAINT; Schema: metrics; Owner: mcp_registry_admin
--

ALTER TABLE ONLY metrics.tool_invocations
    ADD CONSTRAINT tool_invocations_pkey PRIMARY KEY (id);


--
-- Name: mcp_servers mcp_servers_name_unique; Type: CONSTRAINT; Schema: registry; Owner: mcp_registry_admin
--

ALTER TABLE ONLY registry.mcp_servers
    ADD CONSTRAINT mcp_servers_name_unique UNIQUE (name);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: registry; Owner: mcp_registry_admin
--

ALTER TABLE ONLY registry.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (id);


--
-- Name: server_metadata server_metadata_pkey; Type: CONSTRAINT; Schema: registry; Owner: mcp_registry_admin
--

ALTER TABLE ONLY registry.server_metadata
    ADD CONSTRAINT server_metadata_pkey PRIMARY KEY (server_id);


--
-- Name: tools tools_pkey; Type: CONSTRAINT; Schema: registry; Owner: mcp_registry_admin
--

ALTER TABLE ONLY registry.tools
    ADD CONSTRAINT tools_pkey PRIMARY KEY (id);


--
-- Name: server_health_metrics server_health_metrics_server_id_mcp_servers_id_fk; Type: FK CONSTRAINT; Schema: metrics; Owner: mcp_registry_admin
--

ALTER TABLE ONLY metrics.server_health_metrics
    ADD CONSTRAINT server_health_metrics_server_id_mcp_servers_id_fk FOREIGN KEY (server_id) REFERENCES registry.mcp_servers(id) ON DELETE CASCADE;


--
-- Name: tool_invocations tool_invocations_server_id_mcp_servers_id_fk; Type: FK CONSTRAINT; Schema: metrics; Owner: mcp_registry_admin
--

ALTER TABLE ONLY metrics.tool_invocations
    ADD CONSTRAINT tool_invocations_server_id_mcp_servers_id_fk FOREIGN KEY (server_id) REFERENCES registry.mcp_servers(id) ON DELETE CASCADE;


--
-- Name: tool_invocations tool_invocations_tool_id_tools_id_fk; Type: FK CONSTRAINT; Schema: metrics; Owner: mcp_registry_admin
--

ALTER TABLE ONLY metrics.tool_invocations
    ADD CONSTRAINT tool_invocations_tool_id_tools_id_fk FOREIGN KEY (tool_id) REFERENCES registry.tools(id) ON DELETE CASCADE;


--
-- Name: server_metadata server_metadata_server_id_mcp_servers_id_fk; Type: FK CONSTRAINT; Schema: registry; Owner: mcp_registry_admin
--

ALTER TABLE ONLY registry.server_metadata
    ADD CONSTRAINT server_metadata_server_id_mcp_servers_id_fk FOREIGN KEY (server_id) REFERENCES registry.mcp_servers(id) ON DELETE CASCADE;


--
-- Name: tools tools_server_id_mcp_servers_id_fk; Type: FK CONSTRAINT; Schema: registry; Owner: mcp_registry_admin
--

ALTER TABLE ONLY registry.tools
    ADD CONSTRAINT tools_server_id_mcp_servers_id_fk FOREIGN KEY (server_id) REFERENCES registry.mcp_servers(id) ON DELETE CASCADE;


--
-- Name: SCHEMA metrics; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA metrics TO mcp_registry_admin;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO mcp_registry_admin;


--
-- Name: SCHEMA registry; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA registry TO mcp_registry_admin;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: metrics; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA metrics GRANT ALL ON SEQUENCES TO mcp_registry_admin;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: metrics; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA metrics GRANT ALL ON TABLES TO mcp_registry_admin;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: registry; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA registry GRANT ALL ON SEQUENCES TO mcp_registry_admin;


--
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: registry; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA registry GRANT ALL ON TYPES TO mcp_registry_admin;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: registry; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA registry GRANT ALL ON TABLES TO mcp_registry_admin;


--
-- PostgreSQL database dump complete
--

